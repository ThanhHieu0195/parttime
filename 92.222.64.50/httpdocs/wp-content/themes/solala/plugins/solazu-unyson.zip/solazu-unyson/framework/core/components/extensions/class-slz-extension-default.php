<?php if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Instances of this class will be created for extensions without class
 */
class SLZ_Extension_Default extends SLZ_Extension
{
	protected function _init()
	{
	}
}
