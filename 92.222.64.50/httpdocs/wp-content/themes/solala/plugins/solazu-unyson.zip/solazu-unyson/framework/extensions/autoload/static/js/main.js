function SLZ_MAIN() {
	//initial wow
	this.wow_function = function() {
		new WOW().init();
	};
	
	this.carousel_function = function() {
		
		/*----------  layout united states  ----------*/
		jQuery(".sc_carousel_posts .slz-carousel-global").each(function() {

			if ( jQuery(this).hasClass('slz-initial') == true )
				return true;

			var cont = jQuery(this).parents('.sc_carousel_posts')

			var carousel_item = parseInt( jQuery(this).attr('data-slidesToShow')),
				dots = jQuery(cont).attr('data-dots'),
				arrow = jQuery(cont).attr('data-arrow'),
				speed = jQuery(cont).attr('data-speed'),
				autoplay = jQuery(cont).attr('data-autoplay'),
				infinite = jQuery(cont).attr('data-infinite'),
				animation = jQuery(cont).attr('data-animation');
			if( speed == 0 || speed == '' || speed == undefined){
				speed = 600;
			}
			if( autoplay == '1' ){
				autoplay = true;
			} else {
				autoplay = false;
			}
			if( infinite == '1' ){
				infinite = true;
			} else {
				infinite = false;
			}
			if ( dots == '1' ) {
				dots = true;
			}else{
				dots = false;
			}
			if ( arrow == '1' ) {
				arrow = true;
			}else{
				arrow = false;
			}
			if ( animation == '1' ) {
				animation = true;
			}else{
				animation = false;
			}

			if (carousel_item == 1) {
				jQuery(this).slick({
					infinite: infinite,
					slidesToShow: 1,
					slidesToScroll: 1,
					speed: speed,
					dots: dots,
					arrows: arrow,
					autoplay: autoplay,
					fade: animation,
					adaptiveHeight: true,
					appendArrows: jQuery(this).parents('.slz-carousel-wrapper').children('.slz-carousel-nav'),
					prevArrow: '<button class="btn btn-prev"><i class="icons fa"></i><span class="text">Previous</span></button>',
					nextArrow: '<button class="btn btn-next"><span class="text">Next</span> <i class="icons fa"></i></button>',
					responsive: [
						{
							breakpoint: 769,
							settings: {
								arrows: false,
								dots: true
							}
						}
					]
				});
			}else if (carousel_item == 2) {
				jQuery(this).slick({
					infinite: infinite,
					slidesToShow: 2,
					slidesToScroll: 2,
					speed: speed,
					dots: dots,
					arrows: arrow,
					autoplay: autoplay,
					fade: animation,
					adaptiveHeight: true,
					appendArrows: jQuery(this).parents('.slz-carousel-wrapper').children('.slz-carousel-nav'),
					prevArrow: '<button class="btn btn-prev"><i class="icons fa"></i><span class="text">Previous</span></button>',
					nextArrow: '<button class="btn btn-next"><span class="text">Next</span> <i class="icons fa"></i></button>',
					responsive: [
						{
							breakpoint: 769,
							settings: {
								arrows: false,
								dots: true
							}
						}, {
							breakpoint: 415,
							settings: {
								slidesToShow: 1,
								slidesToScroll: 1,
								arrows: false,
								dots: true
							}
						}
					]
				});
			}else if (carousel_item == 3) {
				jQuery(this).slick({
					infinite: infinite,
					slidesToShow: 3,
					slidesToScroll: 3,
					speed: speed,
					dots: dots,
					arrows: arrow,
					autoplay: autoplay,
					fade: animation,
					adaptiveHeight: true,
					appendArrows: jQuery(this).parents('.slz-carousel-wrapper').children('.slz-carousel-nav'),
					prevArrow: '<button class="btn btn-prev"><i class="icons fa"></i><span class="text">Previous</span></button>',
					nextArrow: '<button class="btn btn-next"><span class="text">Next</span> <i class="icons fa"></i></button>',
					responsive: [
						{
							breakpoint: 769,
							settings: {
								slidesToShow: 2,
								slidesToScroll: 2,
								arrows: false,
								dots: true
							}
						}, {
							breakpoint: 415,
							settings: {
								slidesToShow: 1,
								slidesToScroll: 1,
								arrows: false,
								dots: true
							}
						}
					]
				});
			}else if (carousel_item == 4) {
				jQuery(this).slick({
					infinite: infinite,
					slidesToShow: 4,
					slidesToScroll: 4,
					speed: speed,
					dots: dots,
					arrows: arrow,
					autoplay: autoplay,
					fade: animation,
					adaptiveHeight: true,
					appendArrows: jQuery(this).parents('.slz-carousel-wrapper').children('.slz-carousel-nav'),
					prevArrow: '<button class="btn btn-prev"><i class="icons fa"></i><span class="text">Previous</span></button>',
					nextArrow: '<button class="btn btn-next"><span class="text">Next</span> <i class="icons fa"></i></button>',
					responsive: [
						{
							breakpoint: 1025,
							settings: {
								slidesToShow: 3,
								slidesToScroll: 3,
							}
						}, {
							breakpoint: 769,
							settings: {
								slidesToShow: 2,
								slidesToScroll: 2,
								arrows: false,
								dots: true
							}
						}, {
							breakpoint: 415,
							settings: {
								slidesToShow: 1,
								slidesToScroll: 1,
								arrows: false,
								dots: true
							}
						}
					]
				});
			}else if (carousel_item >= 5) {
				jQuery(this).slick({
					infinite: infinite,
					slidesToShow: carousel_item,
					slidesToScroll: carousel_item,
					speed: speed,
					dots: dots,
					arrows: arrow,
					autoplay: autoplay,
					fade: animation,
					adaptiveHeight: true,
					appendArrows: jQuery(this).parents('.slz-carousel-wrapper').children('.slz-carousel-nav'),
					prevArrow: '<button class="btn btn-prev"><i class="icons fa"></i><span class="text">Previous</span></button>',
					nextArrow: '<button class="btn btn-next"><span class="text">Next</span> <i class="icons fa"></i></button>',
					responsive: [
						{
							breakpoint: 1025,
							settings: {
								slidesToShow: 4,
								slidesToScroll: 4,
							}
						}, {
							breakpoint: 769,
							settings: {
								slidesToShow: 3,
								slidesToScroll: 3,
								arrows: false,
								dots: true
							}
						}, {
							breakpoint: 601,
							settings: {
								slidesToShow: 2,
								slidesToScroll: 2,
								arrows: false,
								dots: true
							}
						}, {
							breakpoint: 415,
							settings: {
								slidesToShow: 1,
								slidesToScroll: 1,
								arrows: false,
								dots: true
							}
						}
					]
				});
			}
			
			jQuery(this).addClass('slz-initial');
		});


		/*----------  layout india  ----------*/
		jQuery(".sc_carousel_posts .slz-carousel-vertical").each(function() {
			
			if ( jQuery(this).hasClass('slz-initial') == true )
				return true;

			var cont = jQuery(this).parents('.sc_carousel_posts')

			var carousel_item = parseInt( jQuery(this).attr('data-slidesToShow')),
				dots = jQuery(cont).attr('data-dots'),
				arrow = jQuery(cont).attr('data-arrow'),
				speed = jQuery(cont).attr('data-speed'),
				autoplay = jQuery(cont).attr('data-autoplay'),
				infinite = jQuery(cont).attr('data-infinite'),
				animation = jQuery(cont).attr('data-animation');
			if( speed == 0 || speed == '' || speed == undefined){
				speed = 500;
			}
			if( autoplay == '1' ){
				autoplay = true;
			} else {
				autoplay = false;
			}
			if( infinite == '1' ){
				infinite = true;
			} else {
				infinite = false;
			}
			if ( dots == '1' ) {
				dots = true;
			}else{
				dots = false;
			}
			if ( arrow == '1' ) {
				arrow = true;
			}else{
				arrow = false;
			}
			if ( animation == '1' ) {
				animation = true;
			}else{
				animation = false;
			}
			
			jQuery(this).slick({
				slidesToShow: carousel_item,
				slidesToScroll: carousel_item,
				vertical: true,
				verticalSwiping: true,
				infinite: infinite,
				speed: speed,
				dots: dots,
				arrows: arrow,
				autoplay: autoplay,
				fade: animation,
				adaptiveHeight: true,
				appendArrows: jQuery(this).parents('.slz-carousel-wrapper'),
				prevArrow: '<button class="btn btn-prev"><i class="icons fa"></i><span class="text">Previous</span></button>',
				nextArrow: '<button class="btn btn-next"><span class="text">Next</span> <i class="icons fa"></i></button>',
				responsive: [
					{
						breakpoint: 768,
						settings: {
							vertical: false,
							verticalSwiping: false,
						}
					}
				]
			});

			jQuery(this).addClass('slz-initial');
		});


		/*----------  layout kingdom  ----------*/
		jQuery('.sc_carousel_posts .slz-block-slider-01').each(function(){

			if ( jQuery(this).hasClass('slick-initialized') == true )
				return true;

			var cont = jQuery(this).parents('.sc_carousel_posts')

			var carousel_item = parseInt( jQuery(this).find('.block-slider-nav-01').attr('data-slidesToShow')),
				dots = jQuery(cont).attr('data-dots'),
				arrow = jQuery(cont).attr('data-arrow'),
				speed = jQuery(cont).attr('data-speed'),
				autoplay = jQuery(cont).attr('data-autoplay'),
				infinite = jQuery(cont).attr('data-infinite'),
				animation = jQuery(cont).attr('data-animation');
			if( speed == 0 || speed == '' || speed == undefined){
				speed = 500;
			}
			if( autoplay == '1' ){
				autoplay = true;
			} else {
				autoplay = false;
			}
			if( infinite == '1' ){
				infinite = true;
			} else {
				infinite = false;
			}
			if ( dots == '1' ) {
				dots = true;
			}else{
				dots = false;
			}
			if ( arrow == '1' ) {
				arrow = true;
			}else{
				arrow = false;
			}
			if ( animation == '1' ) {
				animation = true;
			}else{
				animation = false;
			}

			jQuery(this).find('.block-slider-main-01').slick({
				slidesToShow: 1,
				slidesToScroll: 1,
				speed: speed,
				dots: dots,
				autoplay: autoplay,
				arrows: arrow,
				infinite: infinite,
				fade: animation,
				asNavFor: jQuery(this).find('.block-slider-nav-01'),
				appendArrows: jQuery(this).parents('.slz-carousel-wrapper'),
				prevArrow: '<button class="btn btn-prev"><i class="icons fa"></i><span class="text">Previous</span></button>',
				nextArrow: '<button class="btn btn-next"><span class="text">Next</span> <i class="icons fa"></i></button>',
				responsive: [{
					breakpoint: 768,
					settings: {
						arrows: false,
					}
				}]
			});

			jQuery(this).find('.block-slider-nav-01').slick({
				infinite: infinite,
				slidesToShow: carousel_item,
				slidesToScroll: 1,
				speed: speed,
				dots: false,
				arrows: false,
				focusOnSelect: true,
				asNavFor: jQuery(this).find('.block-slider-main-01'),
				responsive: [{
					breakpoint: 768,
					settings: {
						dots: true,
						}
					}, {
					breakpoint: 381,
					settings: {
						dots: true,
						slidesToShow: 2
					}
				}]
			});
		});


		/*----------  layout turkey + brazil ----------*/
		jQuery(".sc_carousel_posts .slz-carousel-syncing").each(function() {

			if ( jQuery(this).hasClass('slz-initial') == true )
				return true;

			var cont = jQuery(this).parents('.sc_carousel_posts')

			var carousel_item = parseInt( jQuery(this).find('.slider-nav').attr('data-slidesToShow')),
				dots1 = jQuery(this).find('.slider-nav').attr('data-dots'),
				dots2 = jQuery(this).find('.slider-for').attr('data-dots'),
				arrow = jQuery(cont).attr('data-arrow'),
				speed = jQuery(cont).attr('data-speed'),
				autoplay = jQuery(cont).attr('data-autoplay'),
				infinite = jQuery(cont).attr('data-infinite'),
				animation = jQuery(cont).attr('data-animation');
			if( speed == 0 || speed == '' || speed == undefined){
				speed = 500;
			}
			if( autoplay == '1' ){
				autoplay = true;
			} else {
				autoplay = false;
			}
			if( infinite == '1' ){
				infinite = true;
			} else {
				infinite = false;
			}
			if ( dots1 == '1' ) {
				dots1 = true;
			}else{
				dots1 = false;
			}
			if ( dots2 == '1' ) {
				dots2 = true;
			}else{
				dots2 = false;
			}
			if ( arrow == '1' ) {
				arrow = true;
			}else{
				arrow = false;
			}
			if ( animation == '1' ) {
				animation = true;
			}else{
				animation = false;
			}

			jQuery(this).find('.slider-for').slick({
				slidesToShow: 1,
				slidesToScroll: 1,
				dots: dots2,
				arrows: arrow,
				speed: speed,
				fade: animation,
				autoplay: autoplay,
				adaptiveHeight: true,
				asNavFor: jQuery(this).find('.slider-nav'),
				prevArrow: '<button class="btn btn-prev"><i class="icons fa"></i><span class="text">Previous</span></button>',
				nextArrow: '<button class="btn btn-next"><span class="text">Next</span> <i class="icons fa"></i></button>',

			});

			jQuery(this).find('.slider-nav').slick({
				slidesToShow: carousel_item,
				slidesToScroll: 1,
				dots: dots1,
				arrows: false,
				speed: speed,
				autoplay: autoplay,
				infinite: infinite,
				centerMode: true,
				centerPadding: '0px',
				focusOnSelect: true,
				asNavFor: jQuery(this).find('.slider-for'),
				responsive: [{
					breakpoint: 1025,
					settings: {
						slidesToShow: 4
						}
					}, {
					breakpoint: 769,
					settings: {
						slidesToShow: 4
						}
					}, {
					breakpoint: 601,
					settings: {
						slidesToShow: 4
						}
					}, {
					breakpoint: 415,
					settings: {
						slidesToShow: 3
						}
					}, {
					breakpoint: 381,
					settings: {
						slidesToShow: 2
					}
				}]
			});
			jQuery(this).addClass('slz-initial');
		});


		/*----------  layout Germany ----------*/
		jQuery(".sc_carousel_posts .slz-carousel-vertical-02").each(function() {

			if ( jQuery(this).hasClass('slz-initial') == true )
				return true;

			var cont = jQuery(this).parents('.sc_carousel_posts'),
				carousel_item = jQuery('.slz-carousel-vertical-02 .slider-nav .item');

			var dots = jQuery(cont).attr('data-dots'),
				arrow = jQuery(cont).attr('data-arrow'),
				speed = jQuery(cont).attr('data-speed'),
				autoplay = jQuery(cont).attr('data-autoplay'),
				infinite = jQuery(cont).attr('data-infinite'),
				animation = jQuery(cont).attr('data-animation');
			if( speed == 0 || speed == '' || speed == undefined){
				speed = 500;
			}
			if( autoplay == '1' ){
				autoplay = true;
			} else {
				autoplay = false;
			}
			if( infinite == '1' ){
				infinite = true;
			} else {
				infinite = false;
			}
			if ( dots == '1' ) {
				dots = true;
			}else{
				dots = false;
			}
			if ( arrow == '1' ) {
				arrow = true;
			}else{
				arrow = false;
			}
			if ( animation == '1' ) {
				animation = true;
			}else{
				animation = false;
			}

			jQuery(this).find('.slider-for').slick({
				slidesToShow: 1,
				slidesToScroll: 1,
				infinite: infinite,
				arrows: arrow,
				fade: animation,
				autoplay: autoplay,
				speed: speed,
				asNavFor: jQuery(this).find('.slider-nav'),
				appendArrows: jQuery(this).parents('.slz-carousel-wrapper').children('.slz-carousel-nav'),
				prevArrow: '<button class="btn btn-prev"><i class="icons fa"></i><span class="text">Previous</span></button>',
				nextArrow: '<button class="btn btn-next"><span class="text">Next</span> <i class="icons fa"></i></button>',
			});

			jQuery(this).find('.slider-nav').slick({
				slidesToShow: carousel_item.length,
				vertical: true,
				infinite: infinite,
				speed: speed,
				slidesToScroll: 1,
				focusOnSelect: true,
				arrows: false,
				asNavFor: jQuery(this).find('.slider-for'),
			});

			jQuery(".slz-carousel-vertical-02 .slider-nav").css("height", jQuery(".slz-carousel-vertical-02 .slider-for").height());
			jQuery(this).addClass('slz-initial');
		});
		
		/*----------  layout Spain ----------*/
		jQuery(".sc_carousel_posts .slz-carousel-center").each(function() {

			if ( jQuery(this).hasClass('slz-initial') == true )
				return true;
			
			var cont = jQuery(this).parents('.sc_carousel_posts')

			var dots = jQuery(cont).attr('data-dots'),
				arrow = jQuery(cont).attr('data-arrow'),
				speed = jQuery(cont).attr('data-speed'),
				autoplay = jQuery(cont).attr('data-autoplay'),
				infinite = jQuery(cont).attr('data-infinite'),
				animation = jQuery(cont).attr('data-animation');
			if( speed == 0 || speed == '' || speed == undefined){
				speed = 500;
			}
			if( autoplay == '1' ){
				autoplay = true;
			} else {
				autoplay = false;
			}
			if( infinite == '1' ){
				infinite = true;
			} else {
				infinite = false;
			}
			if ( dots == '1' ) {
				dots = true;
			}else{
				dots = false;
			}
			if ( arrow == '1' ) {
				arrow = true;
			}else{
				arrow = false;
			}
			if ( animation == '1' ) {
				animation = true;
			}else{
				animation = false;
			}
			
			jQuery(this).slick({
				infinite: infinite,
				autoplay: autoplay,
				dots: dots,
				arrows: arrow,
				speed: speed,
				fade: animation,
				centerMode: true,
				slidesToShow: 1,
				centerPadding: '22%',
				appendArrows: jQuery(this).parents('.slz-carousel-wrapper').children('.slz-carousel-nav'),
				prevArrow: '<button class="btn btn-prev"><i class="icons fa"></i><span class="text">Previous</span></button>',
				nextArrow: '<button class="btn btn-next"><span class="text">Next</span><i class="icons fa"></i></button>',
				responsive: [
					{
						breakpoint: 1025,
						settings: {
							centerPadding: '15%',
						}
					},
					{
						breakpoint: 769,
						settings: {
							centerPadding: '70px',
						}
					},
					{
						breakpoint: 481,
						settings: {
							arrows: false,
							centerPadding: '15px',
						}
					}
				]
			});
		});

		/*----------  Related Article  ----------*/
		jQuery(".slz_single_relate_post .slz-carousel").each(function() {
			var carousel_item = parseInt(jQuery(this).attr('data-slidestoshow'));
			if (carousel_item == 1) {
				jQuery(this).slick({
					infinite: true,
					slidesToShow: 1,
					slidesToScroll: 1,
					speed: 600,
					adaptiveHeight: true,
					dots: false,
					arrows: true,
					appendArrows: jQuery(this).parents('.slz-carousel-wrapper'),
					prevArrow: '<button class="btn btn-prev"><i class="fa fa-long-arrow-left"></i><span class="text">Previous</span></button>',
					nextArrow: '<button class="btn btn-next"><span class="text">Next</span> <i class="fa fa-long-arrow-right"></i></button>'
				});
			}
			if (carousel_item == 2) {
				jQuery(this).slick({
					infinite: true,
					slidesToShow: carousel_item,
					slidesToScroll: 1,
					speed: 600,
					dots: false,
					arrows: true,
					adaptiveHeight: true,
					appendArrows: jQuery(this).parents('.slz-carousel-wrapper'),
					prevArrow: '<button class="btn btn-prev"><i class="fa fa-long-arrow-left"></i><span class="text">Previous</span></button>',
					nextArrow: '<button class="btn btn-next"><span class="text">Next</span> <i class="fa fa-long-arrow-right"></i></button>',
					responsive: [{
						breakpoint: 481,
						settings: {
							slidesToShow: 1,
							slidesToScroll: 1,
						}
					}]
				});
			}
			if (carousel_item == 3) {
				jQuery(this).slick({
					infinite: true,
					slidesToShow: carousel_item,
					slidesToScroll: 1,
					speed: 600,
					adaptiveHeight: true,
					dots: false,
					arrows: true,
					appendArrows: jQuery(this).parents('.slz-carousel-wrapper'),
					prevArrow: '<button class="btn btn-prev"><i class="fa fa-long-arrow-left"></i><span class="text">Previous</span></button>',
					nextArrow: '<button class="btn btn-next"><span class="text">Next</span> <i class="fa fa-long-arrow-right"></i></button>',
					responsive: [{
						breakpoint: 769,
						settings: {
							slidesToShow: 2,
							slidesToScroll: 2,
						}
					}, {
						breakpoint: 481,
						settings: {
							slidesToShow: 1,
							slidesToScroll: 1,
						}
					}]
				});
			}
			if (carousel_item >= 4) {
				jQuery(this).slick({
					infinite: true,
					slidesToShow: carousel_item,
					slidesToScroll: 1,
					speed: 600,
					adaptiveHeight: true,
					dots: false,
					arrows: true,
					appendArrows: jQuery(this).parents('.slz-carousel-wrapper'),
					prevArrow: '<button class="btn btn-prev"><i class="fa fa-long-arrow-left"></i><span class="text">Previous</span></button>',
					nextArrow: '<button class="btn btn-next"><span class="text">Next</span> <i class="fa fa-long-arrow-right"></i></button>',
					responsive: [{
						breakpoint: 1025,
						settings: {
							slidesToShow: 3,
							slidesToScroll: 3,
						}
					}, {
						breakpoint: 769,
						settings: {
							slidesToShow: 2,
							slidesToScroll: 2,
						}
					}, {
						breakpoint: 481,
						settings: {
							slidesToShow: 1,
							slidesToScroll: 1,
						}
					}]
				});
			}
		});

		/*----------  Post slider Widgets  ----------*/
		jQuery(".slz-widget-post-slider .slz-carousel-global").each(function() {

			if ( jQuery(this).hasClass('slz-initial') == true )
				return true;

			jQuery(this).slick({
				infinite: true,
				slidesToShow: 1,
				slidesToScroll: 1,
				dots: false,
				arrows: true,
				autoplay: true,
				adaptiveHeight: true,
				appendArrows: jQuery(this).parents('.slz-carousel-wrapper').children('.slz-carousel-nav'),
				prevArrow: '<button class="btn btn-prev"><i class="icons fa"></i><span class="text">Previous</span></button>',
				nextArrow: '<button class="btn btn-next"><span class="text">Next</span> <i class="icons fa"></i></button>',
			});
			
			jQuery(this).addClass('slz-initial');
		});
	};

	this.comment_rating = function() {
		jQuery('.comment-form-rating .stars a').on('click', function(e){
			e.preventDefault();
			jQuery('.comment-form-rating .stars').find('a').removeClass('active');
			jQuery(this).addClass('active');
			jQuery(this).closest('.comment-form-rating').find('input[name="rating"]').val( jQuery(this).html() );
		});
	};
	
	// project carousel shortcode
	

	this.portfolio_carousel_sc = function() {
		if ( jQuery('.sc_portfolio_list .portfolio_slide_slick').length ) {
			jQuery('.sc_portfolio_list').each(function() {
				var item = jQuery(this).attr('data-item');
				var block = '.' + item + ' ';
				var slick_block = jQuery(block + ".portfolio_slide_slick");
				if ( slick_block.length && !slick_block.hasClass('slick-initialized') ) {
					var slick_json = jQuery(slick_block).data('slick-json');
					if (typeof slick_json !== 'undefined') {
						var centerMode = {centerMode:false}
						jQuery.extend( slick_json, centerMode );
						slick_block.slick( slick_json );
					}
				}
			});
		}

	}
	
	this.sc_causes_progressbar = function () {
		if ( jQuery('.sc_causes_block_layout_1 .slz-progress-bar-01').length || jQuery('.sc_causes_block_layout_2 .slz-progress-bar-01').length ) {
			jQuery(".progress-bar").each(function() {
				var unit = jQuery(this).attr('data-unit');
				var each_bar_width = jQuery(this).attr('aria-valuenow');
				jQuery(this).width(each_bar_width + '%');
				jQuery(this).parent().parent().find('.percent').attr('data-to', each_bar_width);
				jQuery(this).parent().parent().find('.percent').countTo({
					onUpdate: function(value) {
						jQuery(this).append(unit);
					}
				});
			});
		}
	};

	this.sc_icon_block = function () {

		if(jQuery('.slz-icon-block').hasClass('has-bg-hover')) {
			jQuery(' .slz-list-icon-block > .item').each( function() { 
				jQuery(this).find('.slz-icon-block.has-bg-hover').hoverdir({
					hoverDelay : 20,
				}); 
			});
		}

		jQuery('.slz-list-icon-block').each(function() {
			
			var max_height = 0,
				height_array = new Array(),
				element = jQuery(this).find('.item');

			setTimeout(function(){

				for (var i = 0; i < element.length; i++) {
					height_array[i] = element[i].offsetHeight;
				}

				max_height = Math.max.apply(Math, height_array);

				element.find('.slz-icon-block').css('height', max_height);

			}, 1000);

		});
	};

	this.sc_pricing_box = function () {

		/*----------  Column 4  ----------*/
		jQuery('.slz-list-pricing-box.slz-column-4').each(function(){

			jQuery(this).slick({
				slidesToShow: 4,
				infinite: false,
				slidesToScroll: 1,
				dots: false,
				arrows: false,
				responsive: [{
					breakpoint: 1025,
					settings: {
						dots: true,
						slidesToShow: 3,
						}
					}, {
					breakpoint: 991,
					settings: {
						dots: true,
						slidesToShow: 2,
						}
					}, {
					breakpoint: 481,
					settings: {
						dots: true,
						slidesToShow: 1
					}
				}]
			});
		});
					
		/*----------  Column 3  ----------*/
		jQuery('.slz-list-pricing-box.slz-column-3').each(function(){

			jQuery(this).slick({
				infinite: false,
				slidesToShow: 3,
				slidesToScroll: 1,
				dots: false,
				arrows: false,
				responsive: [{
					breakpoint: 991,
					settings: {
						dots: true,
						slidesToShow: 2
						}
					}, {
					breakpoint: 481,
					settings: {
						dots: true,
						slidesToShow: 1
					}
				}]
			});
		});

		/*----------  Column 2  ----------*/
		jQuery('.slz-list-pricing-box.slz-column-2').each(function(){
			jQuery(this).slick({
				infinite: false,
				slidesToShow: 2,
				slidesToScroll: 1,
				dots: false,
				arrows: false,
				responsive: [{
					breakpoint: 481,
					settings: {
						dots: true,
						slidesToShow: 1
					}
				}]
			});
		});
	};

	this.tab_filter = function() {
		// Responsive Tab Filter SC Isotope
		if( jQuery('.tab-filter-wrapper .tab-filter').length ) {

			jQuery('.tab-filter-wrapper .tab-filter').each(function() {
				var tab_filter = jQuery(this);

				tab_filter.slick({
					mobileFirst: true,
					slidesToShow: 1,
					slidesToScroll: 1,
					arrows: true,
					infinite: true,
					fade: false,
					focusOnSelect: true,
					centerMode: true,
					centerPadding: '0px',
					responsive: [
						{
							breakpoint: 600,
							settings: {
								slidesToShow: 3,
							}
						},
						{
							breakpoint: 767,
							settings: 'unslick',
						}
					]
				});

				tab_filter.on('afterChange', function() {
					tab_filter.find('.slick-center').trigger('click');
				});
			});
		}

		// Responsive Tab Filter SC Portfolio (Pending)
		// if( jQuery('.sc_portfolio_list .tab-list').length ) {

		// 	jQuery('.sc_portfolio_list .tab-list').each(function() {

		// 		var tab_list = jQuery(this);

		// 		if (jQuery(window).width() < 767) {
		// 			if ( tab_list.find('.dropdown').length ) {
		// 				var drop_down = tab_list.find('.drop_down');
		// 				var extra_item = tab_list.find('.dropdown-menu li');

		// 				tab_list.append(extra_item);

		// 				drop_down.remove();
		// 			}
		// 		}

		// 		tab_list.slick({
		// 			mobileFirst: true,
		// 			slidesToShow: 1,
		// 			slidesToScroll: 1,
		// 			arrow: true,
		// 			infinite: true,
		// 			fade: false,
		// 			focusOnSelect: true,
		// 			centerMode: true,
		// 			centerPadding: '0px',
		// 			responsive: [
		// 				{
		// 					breakpoint: 600,
		// 					settings: {
		// 						slidesToShow: 3,
		// 					}
		// 				},
		// 				{
		// 					breakpoint: 767,
		// 					settings: 'unslick',
		// 				}
		// 			]
		// 		});

		// 		tab_list.on('afterChange', function() {
		// 			tab_list.find('.slick-center .link').trigger('click');
		// 		});

		// 	});
		// }
	};

	this.select_footer = function() {
		jQuery(".footer-style .switchers-content .btn:last-child").on('click', function(e){
			e.preventDefault();
			jQuery(".slz-wrapper-footer").addClass("slz-footer-fixed");

			var offsetHeight = jQuery('.slz-wrapper-footer').height();

			jQuery(".slz-main-content").css("margin-bottom", offsetHeight + "px");
		});
	};

	
}


var slz_main_obj = new SLZ_MAIN();


jQuery(document).ready(function() {
	slz_main_obj.wow_function();
	slz_main_obj.carousel_function();
	slz_main_obj.comment_rating();
	slz_main_obj.portfolio_carousel_sc();
	slz_main_obj.sc_causes_progressbar();
	slz_main_obj.sc_icon_block();
	slz_main_obj.sc_pricing_box();
	slz_main_obj.tab_filter();
	slz_main_obj.select_footer();

	jQuery('audio.audio-format').mediaelementplayer();
	jQuery(window).on('resize', function() {
		jQuery('audio.audio-format').mediaelementplayer();
	});
});

