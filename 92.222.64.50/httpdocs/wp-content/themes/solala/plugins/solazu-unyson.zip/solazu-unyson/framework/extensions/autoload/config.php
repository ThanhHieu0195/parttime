<?php if ( ! defined( 'ABSPATH' ) ) {
	die( 'Forbidden' );
}

$cfg = array();
$cfg['enable_extension_css'] = array(
	'donation',
	'events',
	'gallery',
	'portfolio',
	'recruitment',
	'teams',
	'testimonials',
	'widgets',
);
$cfg['enable_breakingnews'] = false;
$cfg['enable_post_format_gallery'] = true;
$cfg['enable_extension_js'] = array(
	'donation',
	'events',
	'gallery',
	'portfolio',
	'services',
	'teams',
	'testimonials',
	'hotelbooking'
);
$cfg['enable_shortcodes_css'] = array(
	'about-me',
	'accordion',
	'author-list',
	'banner',
	'button',
	'contact',
	'counter',
	'counterv2',
	'features-block',
	'icon-box',
	'image-carousel',
	'main-title',
	'posts-carousel',
	'posts-grid',
	'pricing-box',
	'process',
	'timeline',
);
$cfg['extra_css'] = array(
	//'test',
);
$cfg['extra_js'] = array(
	'video',
);