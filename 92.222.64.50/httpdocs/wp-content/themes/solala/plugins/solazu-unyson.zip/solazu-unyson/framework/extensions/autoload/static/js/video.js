jQuery(function($) {
    "use strict";

    var SLZ = window.SLZ || {};

    SLZ.videoFunction = function() {

        // General Video 
        if ($('.slz-block-video').length) {
            $('.slz-block-video').each(function() {
                var container = $(this),
                    obj_video = container.find('.video-embed'),
                    video_origin_src = '';
                if( obj_video[0] != undefined) {
                	video_origin_src = obj_video[0].src;
                }

                container.find('.btn-play').on('click', function(e) {
                    obj_video.addClass('show-video');
                    if( obj_video[0] != undefined ) {
                        obj_video[0].src += '&autoplay=1';
                    }
                    container.find('.btn-close').addClass('show-video');
                    e.preventDefault();
                });

                container.find('.btn-close').on('click', function(e) {
                    obj_video.removeClass('show-video');
                    $(this).removeClass('show-video');
                    if( obj_video[0] != undefined ) {
                        obj_video[0].src = video_origin_src;
                    }
                });

                container.find('.modal').on('hide.bs.modal', function () {
                    obj_video.removeClass('show-video');
                    if( obj_video[0] != undefined ) {
                        obj_video[0].src = video_origin_src;
                    }
                });

            });
        }

        // Video List
        if( $('.sc_video_list').length ) {
            $('.sc_video_list').each(function() {
                var sc_video = $(this);
                sc_video.find('.tab-list .tab_item').on('click', function() {
                    if ( !$(this).hasClass('active') ) {
                        if (sc_video.find('.tab-content .tab-pane.active .video-embed').hasClass('show-video')) {
                            sc_video.find('.tab-content .tab-pane.active .video-embed').removeClass('show-video');
                            sc_video.find('.tab-content .tab-pane.active .btn-close').removeClass('show-video');
                        }
                        setTimeout(function(){
                            var video_list = sc_video.find('.tab-content .tab-pane .video-embed');
                            for (var i = video_list.length - 1; i >= 0; i--) {
                                if( video_list[i].src.substr(video_list[i].src.length - 11, 11) == "&autoplay=1" ) {
                                    video_list[i].src = video_list[i].src.substring(0, video_list[i].src.length - 11);
                                }
                            }
                        }, 300);
                    }
                        
                });
            });
        }
    }

    /*======================================
    =            INIT FUNCTIONS            =
    ======================================*/

    $(document).ready(function() {
        SLZ.videoFunction();
    });
    /*=====  End of INIT FUNCTIONS  ======*/

});
