jQuery(function ($) {
    "use strict";

    $.slz_room_scroll_to = function (element) {
        if (element.length) {
            $('body,html').animate({
                scrollTop: element.offset().top - 100
            }, 900);
        }
        return false;
    }

    $.slz_room_archive = function () {
        // Datepicker Range
        $('.input-daterange').datepicker({
            format: "mm/dd/yyyy",
            startDate: '-0d',
            daysOfWeekHighlighted: "0,6",
            autoclose: true,
            todayHighlight: true
        });
        // Select Options
        $('select[data-max]').each(function (idx, dom) {
            var max = $(dom).data('max');
            var out = '';
            for (var i = 1; i <= max; i++) {
                out += '<option value="' + i + '">' + i + '</option>';
            }
            $(dom).find('option').after(out);
        });
        //
        $('.room-archive-wrapper .btn-check-available').click(function (e) {
            e.preventDefault();
            var container = $(this).closest('.search-wrapper');
            var $this = $(this);
            var arriving = $('#arriving', container).val();
            var departing = $('#departing', container).val();
            var adult = $('#adult', container).val();
            var child = $('#child', container).val();

            var data = {
                arriving: arriving,
                departing: departing,
                adult: adult,
                child: child
            };

            $.fn.Form.ajax(['hotelbooking', 'ajax_archive_search'], [data], function (res) {
                $('.rooms-archive-wrapper').html(res);
                slz_main_obj.slz_room_progressbar_1();
                slz_main_obj.slz_room_progressbar_2();
                $.slz_room_scroll_to($('.slz-main-content'));
                $.slz_room_selectbox();
            });
        });
        $('.room-detail-wrapper .btn-choose-option').on('click', function (e) {
            e.preventDefault();
            $.slz_room_scroll_to($('.block-booking-option-title'));
        });
    };

    $.slz_room_carousel = function () {
        /*----------  layout united states  ----------*/
        $(".sc_room_carousel .room_slide_slick").each(function () {

            var carousel_item = parseInt($(this).attr('data-slidestoshow')),
                dots = $(this).attr('data-dotshow'),
                arrow = $(this).attr('data-arrowshow'),
                speed = parseInt($(this).attr('data-slidespeed')),
                infinite = $(this).attr('data-infinite'),
                autoplay = $(this).attr('data-autoplay');
            if (speed == 0 || speed == '' || speed == undefined) {
                speed = 600;
            }
            if (autoplay == '1') {
                autoplay = true;
            } else {
                autoplay = false;
            }
            if (infinite == '1') {
                infinite = true;
            } else {
                infinite = false;
            }
            if (dots == '1') {
                dots = true;
            } else {
                dots = false;
            }
            if (arrow == '1') {
                arrow = true;
            } else {
                arrow = false;
            }

            if (carousel_item == 1) {
                $(this).slick({
                    infinite: infinite,
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    speed: speed,
                    dots: dots,
                    arrows: arrow,
                    autoplay: autoplay,
                    adaptiveHeight: true,
                    appendArrows: $(this).parents('.slz-carousel-wrapper'),
                    prevArrow: '<button class="btn btn-prev"><i class="icons fa"></i></button>',
                    nextArrow: '<button class="btn btn-next"><i class="icons fa"></i></button>',
                    responsive: [
                        {
                            breakpoint: 1024,
                            settings: {
                                arrows: false,
                                dots: true
                            }
                        }
                    ]
                });
            } else if (carousel_item == 2) {
                $(this).slick({
                    infinite: infinite,
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    speed: speed,
                    dots: dots,
                    arrows: arrow,
                    autoplay: autoplay,
                    adaptiveHeight: true,
                    appendArrows: $(this).parents('.slz-carousel-wrapper'),
                    prevArrow: '<button class="btn btn-prev"><i class="icons fa"></i></button>',
                    nextArrow: '<button class="btn btn-next"><i class="icons fa"></i></button>',
                    responsive: [
                        {
                            breakpoint: 1025,
                            settings: {
                                arrows: false,
                                dots: true
                            }
                        }, {
                            breakpoint: 481,
                            settings: {
                                slidesToShow: 1,
                                slidesToScroll: 1,
                                arrows: false,
                                dots: true
                            }
                        }
                    ]
                });
            } else if (carousel_item >= 3) {
                $(this).slick({
                    infinite: infinite,
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    speed: speed,
                    dots: dots,
                    arrows: arrow,
                    autoplay: autoplay,
                    adaptiveHeight: true,
                    appendArrows: $(this).parents('.slz-carousel-wrapper'),
                    prevArrow: '<button class="btn btn-prev"><i class="icons fa"></i></button>',
                    nextArrow: '<button class="btn btn-next"><i class="icons fa"></i></button>',
                    responsive: [
                        {
                            breakpoint: 1025,
                            settings: {
                                slidesToShow: 2,
                                arrows: false,
                                dots: true
                            }
                        }, {
                            breakpoint: 481,
                            settings: {
                                slidesToShow: 1,
                                slidesToScroll: 1,
                                arrows: false,
                                dots: true
                            }
                        }
                    ]
                });
            }
        });
    };

    $.slz_room_room_booking = function () {
        $(document).on('click', '.room-booking-wrapper .btn-booking-package', function () {
            $.slz_room_booking_package($(this));
        });
        $('.extra-item input[type="checkbox"]').change(function () {
            var search_wrap = $('.sc-room-search .search-wrapper');
            var arriving = $('input[name="arriving"]', search_wrap).val();
            var departing = $('input[name="departing"]', search_wrap).val();
            var adult = $('input[name="adult"]', search_wrap).val();
            var children = $('input[name="child"]', search_wrap).val();
            var ei = $(this);
            if( ei.is(':checked') ) {
                var data = {
                    id:ei.val(),
                    arriving:arriving,
                    departing:departing,
                    adult:adult,
                    children:children
                };
                $.fn.Form.ajax(['hotelbooking', 'ajax_add_extra_item'], [data], function (res) {
                    res = jQuery.parseJSON(res)
                    if (res.success) {
                        window.location.reload( true );
                    } else {
                        ei.prop('checked', false);
                        if(res.message) {
                            alert( res.message );
                        }
                    }
                });
            } else {
                var data = { id:ei.val() };
                $.fn.Form.ajax(['hotelbooking', 'ajax_remove_extra_item_by_id'], [data], function (res) {
                    res = jQuery.parseJSON(res)
                    if (res.success) {
                        window.location.reload( true );
                    } else {
                        ei.prop('checked', true);
                        if(res.message) {
                            alert( res.message );
                        }
                    }
                });
            }
        });
        $('.checkout-item .btn-remove-ei').click(function (e) {
            e.preventDefault();
            var ei = $(this);
            var data = { key:ei.data('id') };
            $.fn.Form.ajax(['hotelbooking', 'ajax_remove_extra_item'], [data], function (res) {
                res = jQuery.parseJSON(res)
                if (res.success) {
                    window.location.reload( true );
                } else {
                    if(res.message) {
                        alert( res.message );
                    }
                }
            });
        });
        $('.checkout-block .btn-remove-room').click(function (e) {
            e.preventDefault();
            var room = $(this);
            var data = { key:room.data('id') };
            $.fn.Form.ajax(['hotelbooking', 'ajax_remove_room'], [data], function (res) {
                res = jQuery.parseJSON(res)
                if (res.success) {
                    window.location.reload( true );
                } else {
                    if(res.message) {
                        alert( res.message );
                    }
                }
            });
        });
    };

    $.slz_room_booking_package = function (btn) {
        var search_wrap = $('.sc-room-search .search-wrapper');
        var arriving = $('input[name="arriving"]', search_wrap).val();
        var departing = $('input[name="departing"]', search_wrap).val();
        var adult = $('input[name="adult"]', search_wrap).val();
        var children = $('input[name="child"]', search_wrap).val();
        if( search_wrap.length > 1 ) {
            var wrapper = btn.parents('.slz-room-packages');
            arriving = wrapper.data('arriving');
            departing = wrapper.data('departing');
            adult = wrapper.data('adults');
            children = wrapper.data('childrens');
        }
        if (arriving == '' || departing == '' || adult == '') {
            $.slz_room_scroll_to(search_wrap);
            return false;
        }
        var package_id = btn.data('package_id');
        var number_of_room = btn.parents('.room-package-booking').find('.number_of_room').val();

        var data = {
            arriving: arriving,
            departing: departing,
            adult: adult,
            children: children,
            package_id: package_id,
            number_of_room: number_of_room
        };

        $.fn.Form.ajax(['hotelbooking', 'ajax_booking_room'], [data], function (res) {
            res = jQuery.parseJSON(res)
            if (res.booking_url) {
                window.location = res.booking_url;
            }
        });
    };

    $.slz_room_selectbox = function () {
        if ($('.selectbox').length) {
            $('.selectbox').each(function () {
                $(this).selectbox();
            });
        }
    };

    $.slz_room_selectbox_close = function () {
        $('body').on('click', function (event) {
            if ($('.sbHolder').has(event.target).length === 0 && !$('.sbHolder').is(event.target)) {
                $(".selectbox").selectbox('close');
            }
        });
    };

    $.slz_room_single_info = function () {
        if ($('.room-detail-wrapper .room-info .block-title-wrapper').length && $(window).width() > 1025) {
            $('.room-detail-wrapper .room-info .block-title-wrapper').on('click', function () {
                $(this).parents('.room-info').toggleClass('show');
            });
        }
        if ($('.sc-room-list .room-header .room-info .block-title-wrapper').length && $(window).width() > 1025) {
            $('.sc-room-list .room-header .room-info .block-title-wrapper').on('click', function () {
                $(this).parents('.room-info').toggleClass('show');
            });
        }
    };

    $.slz_room_service_carousel = function () {
        /* Custom effects registration - feature available in the Velocity UI pack */
        //none
        if (!$('.slz_shortcode.sc-service-carousel').length) {
            return;
        }
        $.Velocity
            .RegisterEffect("translateUp", {
                defaultDuration: 1,
                calls: [
                    [{translateY: '-100%'}, 1]
                ]
            });
        $.Velocity
            .RegisterEffect("translateDown", {
                defaultDuration: 1,
                calls: [
                    [{translateY: '100%'}, 1]
                ]
            });
        $.Velocity
            .RegisterEffect("translateNone", {
                defaultDuration: 1,
                calls: [
                    [{translateY: '0', opacity: '1', scale: '1', rotateX: '0', boxShadowBlur: '0'}, 1]
                ]
            });

        //scale down
        $.Velocity
            .RegisterEffect("scaleDown", {
                defaultDuration: 1,
                calls: [
                    [{opacity: '0', scale: '0.7', boxShadowBlur: '40px'}, 1]
                ]
            });

        var lastScrollTop = 0;
        $(window).on('scroll load', function (event) {
            if ($(window).width() >= 1024) {
                var offset_first = $(".slz-list-service-carousel .first-child").offset().top;
                var offset_scroll = $(window).scrollTop();
                var height_service = $(".slz-list-service-carousel").height();
                var st = $(window).scrollTop();
                if (offset_scroll >= offset_first) {
                    $(".slz-list-service-carousel .first-child").removeClass('fixed-top');
                } else {
                    $(".slz-list-service-carousel .first-child").addClass('fixed-top');
                }

                var last_child = $(".slz-list-service-carousel .last-child").height();
                if (st > lastScrollTop) {

                    if (offset_scroll >= (height_service + offset_first - last_child + 100)) {
                        $(".slz-list-service-carousel .last-child").addClass('opacity');
                    } else {
                        $(".slz-list-service-carousel .last-child").removeClass('opacity');
                    }
                    $(".slz-list-service-carousel .last-child").removeClass('fixed-top');
                    //console.log("down");
                } else {

                    if (offset_scroll < (height_service + offset_first - last_child)) {
                        $(".slz-list-service-carousel .last-child").removeClass('opacity');
                    } else if (offset_scroll >= (height_service + offset_first)) {
                        $(".slz-list-service-carousel .last-child").addClass('fixed-top');
                    }
                    //console.log("up");
                }
                lastScrollTop = st;

            } else {
                $(".slz-list-service-carousel .first-child").removeClass('fixed-top');
                $(".slz-list-service-carousel .last-child").removeClass('opacity');
            }
        });
        if ($(window).width() >= 1024) {
            $('.slz-list-service-carousel .cd-section').each(function () {
                var height_block = $(this).find('.slz-service-carousel').height();
                var height_window = $(window).height();
                if (height_block >= height_window) {
                    $(this).css('height', height_window);
                } else {
                    $(this).css('height', height_block);
                }
            });
        }
        window.onresize = function (event) {
            if ($(window).width() >= 1024) {
                $('.slz-list-service-carousel .cd-section').each(function () {
                    var height_block = $(this).find('.slz-service-carousel').height();
                    var height_window = $(window).height();
                    if (height_block >= height_window) {
                        $(this).css('height', height_window);
                    } else {
                        $(this).css('height', height_block);
                    }
                });
            } else {
                $('.slz-list-service-carousel .cd-section').each(function () {
                    $(this).css('height', 'auto');
                });
            }
        };

        //variables
        var hijacking = 'off',
            animationType = 'scaleDown',
            delta = 0,
            scrollThreshold = 5,
            actual = 1,
            animating = false;

        //DOM elements
        var sectionsAvailable = $('.cd-section'),
            verticalNav = $('.cd-vertical-nav'),
            prevArrow = verticalNav.find('a.cd-prev'),
            nextArrow = verticalNav.find('a.cd-next');


        //check the media query and bind corresponding events
        var MQ = deviceType(),
            bindToggle = false;

        bindEvents(MQ, true);

        $(window).on('resize', function () {
            MQ = deviceType();
            bindEvents(MQ, bindToggle);
            if (MQ == 'mobile') bindToggle = true;
            if (MQ == 'desktop') bindToggle = false;
        });

        function bindEvents(MQ, bool) {

            if (MQ == 'desktop' && bool) {
                //bind the animation to the window scroll event, arrows click and keyboard
                if (hijacking == 'on') {
                    initHijacking();
                    $(window).on('DOMMouseScroll mousewheel', scrollHijacking);
                } else {
                    scrollAnimation();
                    $(window).on('scroll', scrollAnimation);
                }
                prevArrow.off('click', prevSection);
                nextArrow.off('click', nextSection);

                $(document).off('keydown');
                //set navigation arrows visibility
                checkNavigation();
            } else if (MQ == 'mobile') {
                //reset and unbind
                resetSectionStyle();
                $(window).off('DOMMouseScroll mousewheel', scrollHijacking);
                $(window).off('scroll', scrollAnimation);
                prevArrow.off('click', prevSection);
                nextArrow.off('click', nextSection);
                $(document).off('keydown');
            }
        }

        function scrollAnimation() {
            //normal scroll - use requestAnimationFrame (if defined) to optimize performance
            (!window.requestAnimationFrame) ? animateSection() : window.requestAnimationFrame(animateSection);
        }

        function animateSection() {
            var scrollTop = $(window).scrollTop(),
                windowHeight = $(window).height(),
                windowWidth = $(window).width();

            sectionsAvailable.each(function () {
                var actualBlock = $(this),
                    offset = scrollTop - actualBlock.offset().top;

                //according to animation type and window scroll, define animation parameters
                var animationValues = setSectionAnimation(offset, windowHeight, animationType);

                transformSection(actualBlock.children('div'), animationValues[0], animationValues[1], animationValues[2], animationValues[3], animationValues[4]);
                ( offset >= 0 && offset < windowHeight ) ? actualBlock.addClass('visible') : actualBlock.removeClass('visible');
            });

            checkNavigation();
        }

        function transformSection(element, translateY, scaleValue, rotateXValue, opacityValue, boxShadow) {
            //transform sections - normal scroll
            element.velocity({
                translateY: translateY + 'vh',
                scale: scaleValue,
                rotateX: rotateXValue,
                opacity: opacityValue,
                boxShadowBlur: boxShadow + 'px',
                translateZ: 0,
            }, 0);
        }

        function initHijacking() {
            // initialize section style - scrollhijacking
            var visibleSection = sectionsAvailable.filter('.visible'),
                topSection = visibleSection.prevAll('.cd-section'),
                bottomSection = visibleSection.nextAll('.cd-section'),
                animationParams = selectAnimation(animationType, false),
                animationVisible = animationParams[0],
                animationTop = animationParams[1],
                animationBottom = animationParams[2];

            visibleSection.children('div').velocity(animationVisible, 1, function () {
                visibleSection.css('opacity', 1);
                topSection.css('opacity', 1);
                bottomSection.css('opacity', 1);
            });
            topSection.children('div').velocity(animationTop, 0);
            bottomSection.children('div').velocity(animationBottom, 0);
        }

        function scrollHijacking(event) {
            // on mouse scroll - check if animate section
            if (event.originalEvent.detail < 0 || event.originalEvent.wheelDelta > 0) {
                delta--;
                ( Math.abs(delta) >= scrollThreshold) && prevSection();
            } else {
                delta++;
                (delta >= scrollThreshold) && nextSection();
            }
            return false;
        }

        function prevSection(event) {
            //go to previous section
            typeof event !== 'undefined' && event.preventDefault();

            var visibleSection = sectionsAvailable.filter('.visible'),
                middleScroll = ( hijacking == 'off' && $(window).scrollTop() != visibleSection.offset().top) ? true : false;
            visibleSection = middleScroll ? visibleSection.next('.cd-section') : visibleSection;

            var animationParams = selectAnimation(animationType, middleScroll, 'prev');
            unbindScroll(visibleSection.prev('.cd-section'), animationParams[3]);

            if (!animating && !visibleSection.is(":first-child")) {
                animating = true;
                visibleSection.removeClass('visible').children('div').velocity(animationParams[2], animationParams[3], animationParams[4])
                    .end().prev('.cd-section').addClass('visible').children('div').velocity(animationParams[0], animationParams[3], animationParams[4], function () {
                    animating = false;
                    if (hijacking == 'off') $(window).on('scroll', scrollAnimation);
                });

                actual = actual - 1;
            }

            resetScroll();
        }

        function nextSection(event) {
            //go to next section
            typeof event !== 'undefined' && event.preventDefault();

            var visibleSection = sectionsAvailable.filter('.visible'),
                middleScroll = ( hijacking == 'off' && $(window).scrollTop() != visibleSection.offset().top) ? true : false;

            var animationParams = selectAnimation(animationType, middleScroll, 'next');
            unbindScroll(visibleSection.next('.cd-section'), animationParams[3]);

            if (!animating && !visibleSection.is(":last-of-type")) {
                animating = true;
                visibleSection.removeClass('visible').children('div').velocity(animationParams[1], animationParams[3], animationParams[4])
                    .end().next('.cd-section').addClass('visible').children('div').velocity(animationParams[0], animationParams[3], animationParams[4], function () {
                    animating = false;
                    if (hijacking == 'off') $(window).on('scroll', scrollAnimation);
                });

                actual = actual + 1;
            }
            resetScroll();
        }

        function unbindScroll(section, time) {
            //if clicking on navigation - unbind scroll and animate using custom velocity animation
            if (hijacking == 'off') {
                $(window).off('scroll', scrollAnimation);
                ( animationType == 'catch') ? $('body, html').scrollTop(section.offset().top) : section.velocity("scroll", {duration: time});
            }
        }

        function resetScroll() {
            delta = 0;
            checkNavigation();
        }

        function checkNavigation() {
            //update navigation arrows visibility
            ( sectionsAvailable.filter('.visible').is(':first-of-type') ) ? prevArrow.addClass('inactive') : prevArrow.removeClass('inactive');
            ( sectionsAvailable.filter('.visible').is(':last-of-type')  ) ? nextArrow.addClass('inactive') : nextArrow.removeClass('inactive');
        }

        function resetSectionStyle() {
            //on mobile - remove style applied with jQuery
            sectionsAvailable.children('div').each(function () {
                $(this).attr('style', '');
            });
        }

        function deviceType() {
            //detect if desktop/mobile
            return window.getComputedStyle(document.querySelector('body'), '::before').getPropertyValue('content').replace(/"/g, "").replace(/'/g, "");
        }

        function selectAnimation(animationName, middleScroll, direction) {
            // select section animation - scrollhijacking
            var animationVisible = 'translateNone',
                animationTop = 'translateUp',
                animationBottom = 'translateDown',
                easing = 'ease',
                animDuration = 800;

            switch (animationName) {
                case 'scaleDown':
                    animationTop = 'scaleDown';
                    easing = 'easeInCubic';
                    break;
                case 'rotate':
                    if (hijacking == 'off') {
                        animationTop = 'rotation.scroll';
                        animationBottom = 'translateNone';
                    } else {
                        animationTop = 'rotation';
                        easing = 'easeInCubic';
                    }
                    break;
                case 'gallery':
                    animDuration = 1500;
                    if (middleScroll) {
                        animationTop = 'scaleDown.moveUp.scroll';
                        animationVisible = 'scaleUp.moveUp.scroll';
                        animationBottom = 'scaleDown.moveDown.scroll';
                    } else {
                        animationVisible = (direction == 'next') ? 'scaleUp.moveUp' : 'scaleUp.moveDown';
                        animationTop = 'scaleDown.moveUp';
                        animationBottom = 'scaleDown.moveDown';
                    }
                    break;
                case 'catch':
                    animationVisible = 'translateUp.delay';
                    break;
                case 'opacity':
                    animDuration = 700;
                    animationTop = 'hide.scaleUp';
                    animationBottom = 'hide.scaleDown';
                    break;
                case 'fixed':
                    animationTop = 'translateNone';
                    easing = 'easeInCubic';
                    break;
                case 'parallax':
                    animationTop = 'translateUp.half';
                    easing = 'easeInCubic';
                    break;
            }

            return [animationVisible, animationTop, animationBottom, animDuration, easing];
        }

        function setSectionAnimation(sectionOffset, windowHeight, animationName) {
            // select section animation - normal scroll
            var scale = 1,
                translateY = 100,
                rotateX = '0deg',
                opacity = 1,
                boxShadowBlur = 0;

            if (sectionOffset >= -windowHeight && sectionOffset <= 0) {
                // section entering the viewport
                translateY = (-sectionOffset) * 130 / windowHeight;
                //default translateY = (-sectionOffset) * 100 / windowHeight;
                switch (animationName) {
                    case 'scaleDown':
                        scale = 1;
                        opacity = 1;
                        break;
                    case 'rotate':
                        translateY = 0;
                        break;
                    case 'gallery':
                        if (sectionOffset >= -windowHeight && sectionOffset < -0.9 * windowHeight) {
                            scale = -sectionOffset / windowHeight;
                            translateY = (-sectionOffset) * 100 / windowHeight;
                            boxShadowBlur = 400 * (1 + sectionOffset / windowHeight);
                        } else if (sectionOffset >= -0.9 * windowHeight && sectionOffset < -0.1 * windowHeight) {
                            scale = 0.9;
                            translateY = -(9 / 8) * (sectionOffset + 0.1 * windowHeight) * 100 / windowHeight;
                            boxShadowBlur = 40;
                        } else {
                            scale = 1 + sectionOffset / windowHeight;
                            translateY = 0;
                            boxShadowBlur = -400 * sectionOffset / windowHeight;
                        }
                        break;
                    case 'catch':
                        if (sectionOffset >= -windowHeight && sectionOffset < -0.75 * windowHeight) {
                            translateY = 100;
                            boxShadowBlur = (1 + sectionOffset / windowHeight) * 160;
                        } else {
                            translateY = -(10 / 7.5) * sectionOffset * 100 / windowHeight;
                            boxShadowBlur = -160 * sectionOffset / (3 * windowHeight);
                        }
                        break;
                    case 'opacity':
                        translateY = 0;
                        scale = (sectionOffset + 5 * windowHeight) * 0.2 / windowHeight;
                        opacity = (sectionOffset + windowHeight) / windowHeight;
                        break;
                }

            } else if (sectionOffset > 0 && sectionOffset <= windowHeight) {
                //section leaving the viewport - still has the '.visible' class
                translateY = (-sectionOffset) * 150 / windowHeight;
                //default translateY = (-sectionOffset) * 100 / windowHeight;
                switch (animationName) {
                    case 'scaleDown':
                        scale = (1 - ( sectionOffset * 0.39 / windowHeight)).toFixed(5);
                        //default scale = (1 - ( sectionOffset * 0.3 / windowHeight)).toFixed(5);
                        opacity = ( 1 - ( sectionOffset / windowHeight) ).toFixed(5);
                        translateY = 0;
                        boxShadowBlur = 40 * (sectionOffset / windowHeight);

                        break;
                    case 'rotate':
                        opacity = ( 1 - ( sectionOffset / windowHeight) ).toFixed(5);
                        rotateX = sectionOffset * 90 / windowHeight + 'deg';
                        translateY = 0;
                        break;
                    case 'gallery':
                        if (sectionOffset >= 0 && sectionOffset < 0.1 * windowHeight) {
                            scale = (windowHeight - sectionOffset) / windowHeight;
                            translateY = -(sectionOffset / windowHeight) * 100;
                            boxShadowBlur = 400 * sectionOffset / windowHeight;
                        } else if (sectionOffset >= 0.1 * windowHeight && sectionOffset < 0.9 * windowHeight) {
                            scale = 0.9;
                            translateY = -(9 / 8) * (sectionOffset - 0.1 * windowHeight / 9) * 100 / windowHeight;
                            boxShadowBlur = 40;
                        } else {
                            scale = sectionOffset / windowHeight;
                            translateY = -100;
                            boxShadowBlur = 400 * (1 - sectionOffset / windowHeight);
                        }
                        break;
                    case 'catch':
                        if (sectionOffset >= 0 && sectionOffset < windowHeight / 2) {
                            boxShadowBlur = sectionOffset * 80 / windowHeight;
                        } else {
                            boxShadowBlur = 80 * (1 - sectionOffset / windowHeight);
                        }
                        break;
                    case 'opacity':
                        translateY = 0;
                        scale = (sectionOffset + 5 * windowHeight) * 0.2 / windowHeight;
                        opacity = ( windowHeight - sectionOffset ) / windowHeight;
                        break;
                    case 'fixed':
                        translateY = 0;
                        break;
                    case 'parallax':
                        translateY = (-sectionOffset) * 50 / windowHeight;
                        break;

                }

            } else if (sectionOffset < -windowHeight) {
                //section not yet visible
                translateY = 100;

                switch (animationName) {
                    case 'scaleDown':
                        scale = 1;
                        opacity = 1;
                        break;
                    case 'gallery':
                        scale = 1;
                        break;
                    case 'opacity':
                        translateY = 0;
                        scale = 0.8;
                        opacity = 0;
                        break;
                }

            } else {
                //section not visible anymore
                translateY = -100;

                switch (animationName) {
                    case 'scaleDown':
                        scale = 0;
                        opacity = 0.7;
                        translateY = 0;
                        break;
                    case 'rotate':
                        translateY = 0;
                        rotateX = '90deg';
                        break;
                    case 'gallery':
                        scale = 1;
                        break;
                    case 'opacity':
                        translateY = 0;
                        scale = 1.2;
                        opacity = 0;
                        break;
                    case 'fixed':
                        translateY = 0;
                        break;
                    case 'parallax':
                        translateY = -50;
                        break;
                }
            }

            return [translateY, scale, rotateX, opacity, boxShadowBlur];
        }
    };

    $.slz_room_submit_paypal_form = function () {
        $('form.paypal-form').submit();
    };

    $.slz_room_open_modal = function () {
        $('.slz-room-open-modal').on('click', function (e) {
            e.preventDefault();
            var $this = $(this);
            var target = $(this).attr('data-target');
            var arriving = $(this).parents('.form-wrapper').find('.arriving-date input').val();
            var departing = $(this).parents('.form-wrapper').find('.departing-date input').val();
            var adult = $(this).parents('.form-wrapper').find('.search-item.number select[name="adults"]').val();
            var child = $(this).parents('.form-wrapper').find('.search-item.number select[name="childrens"]').val();
            if (arriving == '' || departing == '' || adult == '') {
                alert('Please enter booking options.');
                return false;
            }
            var data = {
                "room_id": $(this).attr('data-id')
            };
            $(this).append('<i class="fa fa-spinner fa-spin"></i>');
            $.fn.Form.ajax_sc(['room_list', 'ajax_get_room_packages'], [data], function (res) {
                $('.fa-spinner', $this).remove();
                if (res != '[FAIL]') {
                    $('.modal-content .slz-room-packages', '#' + target)
                        .attr('data-arriving', arriving)
                        .attr('data-departing', departing)
                        .attr('data-adults', adult)
                        .attr('data-childrens', child)
                        .html(res);
                    $.slz_room_selectbox();
                    $('#' + target).modal('show');
                }
            });
        });
    };

    $.payment = function () {
        $('.payment-item label').on('click', function (event) {
            if ($(this).next().hasClass('in')) {
                $(this).next().collapse('show');
            }
            else {
                $(this).parents('.payment-block').find('.collapse').collapse('hide');
                $(this).next().collapse('show');
            }
        })
    };

    $.slz_room_booking_select_pay_option = function () {
        $('.pay_type input[name="pay_option"]').change(function () {
            var amount = $(this).data('amount');
            var form = $(this).parents('form');
            var final_price = form.find('.final_price .price');
            final_price.html('<span>$</span>' + amount);
        });
    };

    $.slz_number_init = function () {
        $('.search-item input[type="number"]').change(function () {
            var field = $(this);
            var min = parseInt(field.attr('min'));
            if (isNaN(min)) {
                min = 0;
            }
            var max = parseInt(field.attr('max'));
            if (isNaN(max)) {
                max = 10;
            }
            var currentVal = parseInt(field.val());
            if (!isNaN(currentVal)) {
                if (currentVal < min) {
                    field.val(min);
                }
                if (currentVal > max) {
                    field.val(max);
                }
            }
            else {
                field.val(min);
            }
        });
        $('.search-item .number-btn .btn-plus').click(function (e) {
            e.preventDefault();
            var field = $(this).parents('.search-item').find('input[type="number"]');
            var step = parseInt(field.attr('step'));
            if (isNaN(step)) {
                step = 1;
            }
            var max = parseInt(field.attr('max'));
            if (isNaN(max)) {
                max = 10;
            }
            var currentVal = parseInt(field.val());
            if (!isNaN(currentVal)) {
                if (currentVal + step <= max) {
                    field.val(currentVal + step);
                }
            }
            else {
                field.val(0);
            }
        });
        $('.search-item .number-btn .btn-minus').click(function (e) {
            e.preventDefault();
            var field = $(this).parents('.search-item').find('input[type="number"]');
            var step = parseInt(field.attr('step'));
            if (isNaN(step)) {
                step = 1;
            }
            var min = parseInt(field.attr('min'));
            if (isNaN(min)) {
                min = 0;
            }
            var currentVal = parseInt(field.val());
            if (!isNaN(currentVal)) {
                if (currentVal - step >= min) {
                    field.val(currentVal - step);
                }
            } else {
                field.val(0);
            }
        });
    };

    $(document).ready(function () {
        jQuery.slz_number_init();
        jQuery.slz_room_archive();
        jQuery.slz_room_room_booking();
        jQuery.slz_room_carousel();
        jQuery.slz_room_selectbox();
        jQuery.slz_room_selectbox_close();
        jQuery.slz_room_single_info();
        jQuery.slz_room_service_carousel();
        jQuery.slz_room_submit_paypal_form();
        jQuery.slz_room_open_modal();
        jQuery.payment();
        jQuery.slz_room_booking_select_pay_option();
    });
});

