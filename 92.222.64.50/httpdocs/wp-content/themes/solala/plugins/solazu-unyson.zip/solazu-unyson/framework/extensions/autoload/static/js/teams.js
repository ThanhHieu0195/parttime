jQuery(function($) {
    "use strict";

    $.slz_team_slider = function() {
        $('.sc_team_block .slz-carousel-wrapper').each(function() {
            var carousel_item = parseInt($(this).attr('data-slidestoshow')),
                dots = $(this).attr('data-dotshow'),
                arrow = $(this).attr('data-arrowshow'),
                speed = $(this).attr('data-speed'),
                autoplay = $(this).attr('data-autoplay'),
                infinite = $(this).attr('data-infinite');

            if( speed == 0 || speed == '' || speed == undefined){
                speed = 600;
            }
            if( autoplay == '1' ){
                autoplay = true;
            } else {
                autoplay = false;
            }
            if( infinite == '1' ){
                infinite = true;
            } else {
                infinite = false;
            }
            if ( dots == '1' ) {
                dots = true;
            }else{
                dots = false;
            }
            if ( arrow == '1' ) {
                arrow = true;
            }else{
                arrow = false;
            }

            if (carousel_item == 1) {
                $(this).slick({
                    infinite: infinite,
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    speed: speed,
                    dots: dots,
                    arrows: arrow,
                    autoplay: autoplay,
                    adaptiveHeight: true,
                    prevArrow: '<button class="btn btn-prev"><i class="icons fa"></i><span class="text">Previous</span></button>',
                    nextArrow: '<button class="btn btn-next"><span class="text">Next</span> <i class="icons fa"></i></button>',
                    responsive: [
                        {
                            breakpoint: 1025,
                            settings: {
                                arrows: false,
                                dots: true
                            }
                        },
                        {
                            breakpoint: 769,
                            settings: {
                                arrows: false,
                                dots: true
                            }
                        }
                    ]
                });
            }
            else if (carousel_item == 2) {
                $(this).slick({
                    infinite: infinite,
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    speed: speed,
                    dots: dots,
                    arrows: arrow,
                    autoplay: autoplay,
                    adaptiveHeight: true,
                    prevArrow: '<button class="btn btn-prev"><i class="icons fa"></i><span class="text">Previous</span></button>',
                    nextArrow: '<button class="btn btn-next"><span class="text">Next</span> <i class="icons fa"></i></button>',
                    responsive: [
                         {
                            breakpoint: 1025,
                            settings: {
                                arrows: false,
                                dots: true
                            }
                        },
                        {
                            breakpoint: 769,
                            settings: {
                                arrows: false,
                                dots: true
                            }
                        }, {
                            breakpoint: 415,
                            settings: {
                                slidesToShow: 1,
                                arrows: false,
                                dots: true
                            }
                        }
                    ]
                });
            }
            else if (carousel_item == 3) {
                $(this).slick({
                    infinite: infinite,
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    speed: speed,
                    dots: dots,
                    arrows: arrow,
                    autoplay: autoplay,
                    adaptiveHeight: true,
                    prevArrow: '<button class="btn btn-prev"><i class="icons fa"></i><span class="text">Previous</span></button>',
                    nextArrow: '<button class="btn btn-next"><span class="text">Next</span> <i class="icons fa"></i></button>',
                    responsive: [
                         {
                            breakpoint: 1025,
                            settings: {
                                arrows: false,
                                dots: true
                            }
                        },
                        {
                            breakpoint: 769,
                            settings: {
                                slidesToShow: 2,
                                arrows: false,
                                dots: true
                            }
                        }, {
                            breakpoint: 415,
                            settings: {
                                slidesToShow: 1,
                                arrows: false,
                                dots: true
                            }
                        }
                    ]
                });
            }
            else if (carousel_item >= 4) {
                $(this).slick({
                    infinite: infinite,
                    slidesToShow: carousel_item,
                    slidesToScroll: 1,
                    speed: speed,
                    dots: dots,
                    arrows: arrow,
                    adaptiveHeight: true,
                    autoplay: autoplay,
                    prevArrow: '<button class="btn btn-prev"><i class="icons fa"></i><span class="text">Previous</span></button>',
                    nextArrow: '<button class="btn btn-next"><span class="text">Next</span> <i class="icons fa"></i></button>',
                    responsive: [
                        {
                            breakpoint: 1025,
                            settings: {
                                slidesToShow: 3,
                                dots:true,
                                arrows:false
                            }
                        }, {
                            breakpoint: 769,
                            settings: {
                                slidesToShow: 2,
                                arrows: false,
                                dots: true
                            }
                        }, {
                            breakpoint: 415,
                            settings: {
                                slidesToShow: 1,
                                arrows: false,
                                dots: true
                            }
                        }
                    ]
                });
            }
        });

        if(jQuery('.sc_team_block').hasClass('la-india')) {
            jQuery('.sc_team_block.la-india .item').each( function() { 
                jQuery(this).find('.slz-team-block').hoverdir({
                    hoverDelay : 20,
                }); 
            });
        }
    };

    $.slz_team_carousel_la_united_states = function(){
        $('.sc_team_carousel.la-united-states .slz-carousel-wrapper').each(function() {
            var dots = $(this).attr('data-dotshow'),
                arrow = $(this).attr('data-arrowshow'),
                infinite = $(this).attr('data-infinite'),
                autoplay = $(this).attr('data-autoplay'),
                carousel_item = parseInt($(this).attr('data-slidestoshow'));
            if ( dots == '1' ) {
                dots = true;
            }else{
                dots = false;
            }
            if ( arrow == '1' ) {
                arrow = true;
            }else{
                arrow = false;
            }
            if( infinite == '1' ){
                infinite = true;
            } else {
                infinite = false;
            }
            if( autoplay == '1' ){
                autoplay = true;
            } else {
                autoplay = false;
            }
            $(this).find('.slider-for').slick({
                fade: true,
                dots: dots,
                arrows: arrow,
                slidesToShow: 1,
                slidesToScroll: 1,
                infinite: infinite,
                autoplay: autoplay,
                asNavFor: $(this).parent().find('.slider-nav'),
                prevArrow: '<button class="btn btn-prev"><i class="icons fa"></i><span class="text">Previous</span></button>',
                nextArrow: '<button class="btn btn-next"><span class="text">Next</span> <i class="icons fa"></i></button>',
                responsive: [
                {
                    breakpoint: 1025,
                    settings: {
                        dots: false,
                        arrows: false,
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        adaptiveHeight: true,
                        dots: false,
                        arrows: false,
                    }
                }]
            });
            $(this).find('.slider-nav').slick({
                dots: false,
                arrows: false,
                slidesToShow: carousel_item,
                slidesToScroll: 1,
                focusOnSelect: true,
                infinite: infinite,
                autoplay: autoplay,
                asNavFor: $(this).parent().find('.slider-for'),
                responsive: [
                {
                    breakpoint: 1025,
                    settings: {
                        slidesToShow: 4,
                        dots: true
                    }
                },
                {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 3,
                        dots: true
                    }
                },
                {
                    breakpoint: 767,
                    settings: {
                        slidesToShow: 3,
                        dots: true,
                    }
                }
                ]
            });

        });
    };
    
    $.slz_team_carousel_la_united_kingdom = function () {
        $('.sc_team_carousel.la-united-kingdom .slz-carousel-wrapper').each(function() {
            var dots = $(this).attr('data-dotshow'),
                arrow = $(this).attr('data-arrowshow'),
                infinite = $(this).attr('data-infinite'),
                autoplay = $(this).attr('data-autoplay'),
                carousel_item = parseInt($(this).attr('data-slidestoshow'));

            if ( dots == '1' ) {
                dots = true;
            }else{
                dots = false;
            }
            if ( arrow == '1' ) {
                arrow = true;
            }else{
                arrow = false;
            }
            if( infinite == '1' ){
                infinite = true;
            } else {
                infinite = false;
            }
            if( autoplay == '1' ){
                autoplay = true;
            } else {
                autoplay = false;
            }
            $(this).find('.slider-for').slick({
                fade: false,
                arrows: false,
                dots: dots,
                slidesToShow: 1,
                slidesToScroll: 1,
                autoplay: autoplay,
                asNavFor: $(this).parent().find('.slider-nav'),
                adaptiveHeight: true,
            });
            $(this).find('.slider-nav').slick({
                fade: false,
                dots: false,
                arrows: arrow,
                slidesToShow: carousel_item,
                slidesToScroll: 1,
                centerMode: true,
                focusOnSelect: true,
                centerPadding: '0px',
                asNavFor: $(this).parent().find('.slider-for'),
                adaptiveHeight: true,
                prevArrow: '<button class="btn btn-prev"><i class="icons fa"></i><span class="text">Previous</span></button>',
                nextArrow: '<button class="btn btn-next"><span class="text">Next</span> <i class="icons fa"></i></button>',
                responsive: [
                    {
                        breakpoint: 1025,
                        settings: {
                            slidesToShow: 5
                        }
                    }, 
                    {
                        breakpoint: 769,
                        settings: {
                            slidesToShow: 3,
                            arrows: false,
                            dots: true
                        }
                    }, 
                    {
                        breakpoint: 601,
                        settings: {
                            arrows: false,
                            dots: true,
                            centerPadding: '120px',
                            slidesToShow: 1,
                        }
                    },
                    {
                        breakpoint: 415,
                        settings: {
                            slidesToShow: 1,
                            arrows: false,
                            dots: true
                        }
                    }
                ]
            });
        })
    };
    
    $(document).ready(function() {
        jQuery.slz_team_slider();
        jQuery.slz_team_carousel_la_united_states();
        jQuery.slz_team_carousel_la_united_kingdom();
    });
});
